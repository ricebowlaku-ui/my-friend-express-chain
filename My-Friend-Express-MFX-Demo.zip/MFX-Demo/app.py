import hashlib
import json
import os
import re
import sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

CHAIN = 'mfx-demo-1'
SUPPLY = 100_000_000  # unit terkecil; 100 unit = 1 MFX
GRANT = 10_000       # 100 MFX percobaan per alamat
FEE = 1             # 0.01 MFX
DB = os.environ.get('MFX_DB', 'mfx.sqlite3')
GENESIS = hashlib.sha256(f'{CHAIN}:{SUPPLY}'.encode()).hexdigest()


def encode(value):
    return json.dumps(value, separators=(',', ':'), ensure_ascii=True)


def digest(value):
    return hashlib.sha256(encode(value).encode()).hexdigest()


def address(public):
    return 'mfx' + hashlib.sha256(bytes.fromhex(public)).hexdigest()[:40]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def apply(state, tx, signature):
    require(isinstance(tx, list) and len(tx) == 7, 'Format transaksi salah')
    chain, kind, public, target, amount, nonce, reference = tx
    require(chain == CHAIN, 'Chain ID salah')
    require(kind in ('faucet', 'transfer', 'payment', 'reward'), 'Jenis salah')
    require(isinstance(public, str) and re.fullmatch(r'[0-9a-f]{64}', public), 'Public key salah')
    require(isinstance(target, str) and re.fullmatch(r'mfx[0-9a-f]{40}', target), 'Alamat salah')
    require(type(amount) is int and 0 < amount <= SUPPLY, 'Jumlah salah')
    require(type(nonce) is int and nonce >= 0, 'Nonce salah')
    require(isinstance(reference, str) and re.fullmatch(r'[A-Za-z0-9 ._-]{0,60}', reference), 'Referensi: maksimal 60 karakter huruf/angka/spasi/._-')
    require(isinstance(signature, str) and re.fullmatch(r'[0-9a-f]{128}', signature), 'Signature salah')
    Ed25519PublicKey.from_public_bytes(bytes.fromhex(public)).verify(
        bytes.fromhex(signature), encode(tx).encode()
    )
    sender = address(public)
    require(nonce == state['nonces'].get(sender, 0), 'Nonce sudah dipakai; refresh saldo')
    balance = state['balances'].get(sender, 0)
    if kind == 'faucet':
        require(target == sender and amount == GRANT, 'Permintaan faucet salah')
        require(sender not in state['claimed'], 'Alamat ini sudah menerima faucet')
        require(state['reserve'] >= GRANT, 'Cadangan faucet habis')
        state['reserve'] -= GRANT
        state['balances'][sender] = balance + GRANT
        state['claimed'].add(sender)
    else:
        require(balance >= amount + FEE, 'Saldo tidak cukup termasuk biaya 0.01 MFX')
        state['balances'][sender] = balance - amount - FEE
        state['balances'][target] = state['balances'].get(target, 0) + amount
        state['reserve'] += FEE
    state['nonces'][sender] = nonce + 1


def replay(db):
    state = {'balances': {}, 'nonces': {}, 'claimed': set(), 'reserve': SUPPLY}
    head, height = GENESIS, 0
    for number, raw, block_hash in db.execute('SELECT height, body, hash FROM blocks ORDER BY height'):
        block = json.loads(raw)
        require(number == height + 1 and block[0] == number and block[1] == head, 'Rantai blok rusak')
        require(digest(block) == block_hash, 'Hash blok tidak cocok')
        apply(state, block[2], block[3])
        height, head = number, block_hash
    require(sum(state['balances'].values()) + state['reserve'] == SUPPLY, 'Pasokan tidak cocok')
    return state, height, head


def connect():
    return sqlite3.connect(DB, timeout=30)


def initialize():
    with connect() as db:
        db.execute('CREATE TABLE IF NOT EXISTS blocks (height INTEGER PRIMARY KEY, body TEXT NOT NULL, hash TEXT NOT NULL)')
        replay(db)


def submit(tx, signature):
    db = connect()
    try:
        db.execute('BEGIN IMMEDIATE')
        state, height, head = replay(db)
        apply(state, tx, signature)
        block = [height + 1, head, tx, signature]
        block_hash = digest(block)
        db.execute('INSERT INTO blocks VALUES (?, ?, ?)', (height + 1, encode(block), block_hash))
        db.commit()
        return {'height': height + 1, 'hash': block_hash}
    finally:
        db.close()


PAGE = r'''<!doctype html>
<html lang="id"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>MFX Demo Wallet</title>
<style>
body{font:16px system-ui;background:#101827;color:#edf5ff;max-width:650px;margin:30px auto;padding:18px}
section{background:#1b2940;padding:20px;border-radius:16px;margin:16px 0}
button,input,select{box-sizing:border-box;padding:13px;margin:6px 0;width:100%;border-radius:9px;border:1px solid #69758a;font:inherit}
button{background:#baff62;color:#142000;font-weight:bold;cursor:pointer}button:disabled{opacity:.5}
code,pre{white-space:pre-wrap;overflow-wrap:anywhere}small{color:#bac8dc}label{display:block;margin-top:12px}
</style>
<h1>My Friend Express</h1><p>MFX · Jaringan demo satu node · Tanpa nilai uang</p>
<section>
<button id="create">Buat wallet</button>
<button id="backup">Unduh cadangan wallet</button>
<label>Pulihkan cadangan JSON<input id="restore" type="file" accept=".json,application/json"></label>
<p>Alamat: <code id="address">Belum ada wallet</code></p>
<h2 id="balance">0 MFX</h2>
<button id="refresh">Refresh saldo</button>
<button id="faucet">Ambil 100 MFX percobaan</button>
<small>Kunci disimpan di browser ini. Cadangan berisi kunci rahasia tanpa enkripsi: simpan pribadi, jangan unggah ke GitHub.</small>
</section>
<section>
<label>Jenis transaksi<select id="kind"><option value="transfer">Transfer</option><option value="payment">Pembayaran demo</option><option value="reward">Kirim reward demo</option></select></label>
<label>Alamat penerima<input id="target" placeholder="mfx..."></label>
<label>Jumlah MFX<input id="amount" inputmode="decimal" placeholder="Contoh: 10.50"></label>
<label>Referensi pesanan<input id="reference" maxlength="60" placeholder="ORDER-001"></label>
<button id="send">Kirim · biaya 0.01 MFX</button>
<small>Reward dikirim dari saldo pengirim. Label pembayaran belum terhubung ke pesanan toko.</small>
</section>
<section><strong>Status</strong><pre id="status">Siap</pre></section>
<section><strong>20 blok terakhir</strong><pre id="blocks"></pre></section>
<script>
const $ = id => document.getElementById(id);
const hex = bytes => Array.from(new Uint8Array(bytes), x => x.toString(16).padStart(2,'0')).join('');
const unhex = s => {
  if(typeof s !== 'string' || !/^(?:[0-9a-f]{2})+$/.test(s)) throw Error('Format kunci salah');
  return Uint8Array.from(s.match(/../g), x => parseInt(x,16));
};
const enc = new TextEncoder();
let wallet, privateKey, ownAddress, network;
async function api(path, body) {
  const r = await fetch(path, body === undefined ? {} : {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)
  });
  const data = await r.json();
  if(!r.ok) throw Error(data.error || 'Permintaan gagal');
  return data;
}
async function activate(w) {
  if(!crypto.subtle) throw Error('Wallet membutuhkan HTTPS atau localhost');
  if(!w || w.chain !== 'mfx-demo-1') throw Error('Cadangan jaringan salah');
  const key = await crypto.subtle.importKey('pkcs8',unhex(w.private),'Ed25519',true,['sign']);
  const pub = await crypto.subtle.importKey('raw',unhex(w.public),'Ed25519',true,['verify']);
  const probe = enc.encode('MFX wallet check');
  const sig = await crypto.subtle.sign('Ed25519',key,probe);
  if(!await crypto.subtle.verify('Ed25519',pub,sig,probe)) throw Error('Pasangan kunci tidak cocok');
  const addr = 'mfx' + hex(await crypto.subtle.digest('SHA-256',unhex(w.public))).slice(0,40);
  localStorage.setItem('mfx-demo-wallet',JSON.stringify(w));
  wallet=w; privateKey=key; ownAddress=addr;
  $('address').textContent=addr;
  await refresh();
}
async function refresh() {
  network = await api('/api/state');
  const units = network.balances[ownAddress] || 0;
  $('balance').textContent = (units/100).toFixed(2)+' MFX';
  const blocks = await api('/api/blocks');
  $('blocks').textContent = blocks.map(b => 'Blok '+b.height+'\n'+b.hash+'\n'+b.kind).join('\n\n') || 'Belum ada transaksi';
}
async function send(kind) {
  if(!wallet) throw Error('Buat atau pulihkan wallet dahulu');
  await refresh();
  let amount=10000, target=ownAddress, reference='';
  if(kind !== 'faucet') {
    const value=$('amount').value.trim();
    if(!/^\d{1,7}(\.\d{1,2})?$/.test(value)) throw Error('Jumlah: maksimal 2 angka desimal, gunakan titik');
    const parts=value.split('.');
    amount=Number(parts[0])*100+Number((parts[1]||'').padEnd(2,'0'));
    target=$('target').value.trim(); reference=$('reference').value.trim();
  }
  const tx=[network.chain,kind,wallet.public,target,amount,network.nonces[ownAddress]||0,reference];
  const signature=hex(await crypto.subtle.sign('Ed25519',privateKey,enc.encode(JSON.stringify(tx))));
  const result=await api('/api/tx',{tx,signature});
  $('status').textContent='Tercatat di node demo. Blok '+result.height+'\n'+result.hash;
  await refresh();
}
function action(id, fn, event='click') {
  $(id).addEventListener(event,async()=>{
    $(id).disabled=true;
    try { await fn(); } catch(e) { $('status').textContent=e.message; }
    finally { $(id).disabled=false; }
  });
}
action('create',async()=>{
  if(localStorage.getItem('mfx-demo-wallet')) throw Error('Wallet sudah ada. Gunakan browser/profil lain untuk wallet kedua.');
  if(!crypto.subtle) throw Error('Buka melalui HTTPS atau localhost');
  const pair=await crypto.subtle.generateKey('Ed25519',true,['sign','verify']);
  await activate({chain:'mfx-demo-1',public:hex(await crypto.subtle.exportKey('raw',pair.publicKey)),private:hex(await crypto.subtle.exportKey('pkcs8',pair.privateKey))});
  $('status').textContent='Wallet dibuat. Unduh cadangan sebelum melanjutkan.';
});
action('backup',async()=>{
  if(!wallet) throw Error('Belum ada wallet');
  const url=URL.createObjectURL(new Blob([JSON.stringify(wallet)],{type:'application/json'}));
  const a=document.createElement('a'); a.href=url; a.download='mfx-wallet-RAHASIA.json'; a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
});
action('restore',async()=>{
  const file=$('restore').files[0]; if(!file) return;
  if(wallet && !confirm('Ganti wallet aktif? Pastikan cadangan wallet lama sudah disimpan.')) return;
  await activate(JSON.parse(await file.text()));
  $('status').textContent='Wallet dipulihkan.';
},'change');
action('refresh',refresh);
action('faucet',()=>send('faucet'));
action('send',()=>send($('kind').value));
(async()=>{
  try {
    const saved=localStorage.getItem('mfx-demo-wallet');
    if(saved) await activate(JSON.parse(saved)); else await refresh();
  } catch(e) { $('status').textContent=e.message; }
})();
</script></html>'''


class Handler(BaseHTTPRequestHandler):
    def reply(self, status, data, html=False):
        payload = (data if html else json.dumps(data)).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'text/html; charset=utf-8' if html else 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/':
            return self.reply(200, PAGE, True)
        try:
            with connect() as db:
                if path == '/api/state':
                    state, height, head = replay(db)
                    return self.reply(200, {'chain': CHAIN, 'height': height, 'head': head,
                        'balances': state['balances'], 'nonces': state['nonces'], 'reserve': state['reserve']})
                if path == '/api/blocks':
                    rows = db.execute('SELECT height, body, hash FROM blocks ORDER BY height DESC LIMIT 20').fetchall()
                    return self.reply(200, [{'height': h, 'hash': v, 'kind': json.loads(b)[2][1]} for h, b, v in rows])
            self.reply(404, {'error': 'Tidak ditemukan'})
        except Exception:
            self.reply(500, {'error': 'Database gagal diverifikasi; periksa node'})

    def do_POST(self):
        if self.path != '/api/tx':
            return self.reply(404, {'error': 'Tidak ditemukan'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            require(0 < length <= 4096, 'Ukuran transaksi salah')
            body = json.loads(self.rfile.read(length))
            require(isinstance(body, dict), 'Body harus objek JSON')
            result = submit(body['tx'], body['signature'])
            self.reply(200, result)
        except InvalidSignature:
            self.reply(400, {'error': 'Tanda tangan tidak sah'})
        except (ValueError, KeyError, TypeError):
            self.reply(400, {'error': 'Transaksi ditolak: periksa saldo, nonce, faucet, alamat, dan format input'})
        except Exception:
            self.reply(500, {'error': 'Node gagal memproses transaksi'})


if __name__ == '__main__':
    initialize()
    host = os.environ.get('HOST', '127.0.0.1')
    port = int(os.environ.get('PORT', '8000'))
    print(f'MFX DEMO: http://{host}:{port}')
    ThreadingHTTPServer((host, port), Handler).serve_forever()
