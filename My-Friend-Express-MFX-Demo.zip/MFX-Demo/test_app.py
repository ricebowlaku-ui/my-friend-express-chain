import tempfile
import unittest
from pathlib import Path
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
import app


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB
        app.DB = str(Path(self.temp.name) / 'test.sqlite3')
        app.initialize()
        self.keys = [Ed25519PrivateKey.generate() for _ in range(2)]
        self.public = [key.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw
        ).hex() for key in self.keys]
        self.addresses = [app.address(public) for public in self.public]

    def tearDown(self):
        app.DB = self.old_db
        self.temp.cleanup()

    def transaction(self, owner, kind, target, amount, nonce):
        tx = [app.CHAIN, kind, self.public[owner], target, amount, nonce, 'ORDER-001']
        return tx, self.keys[owner].sign(app.encode(tx).encode()).hex()

    def fund(self, owner=0):
        pair = self.transaction(owner, 'faucet', self.addresses[owner], app.GRANT, 0)
        app.submit(*pair)
        return pair

    def test_payment_reward_self_transfer_and_persistence(self):
        self.fund()
        app.submit(*self.transaction(0, 'payment', self.addresses[1], 1000, 1))
        app.submit(*self.transaction(1, 'reward', self.addresses[0], 100, 0))
        app.submit(*self.transaction(0, 'transfer', self.addresses[0], 50, 2))
        app.initialize()
        with app.connect() as db:
            state, height, _ = app.replay(db)
        self.assertEqual(height, 4)
        self.assertEqual(state['balances'][self.addresses[0]], 9098)
        self.assertEqual(state['balances'][self.addresses[1]], 899)
        self.assertEqual(sum(state['balances'].values()) + state['reserve'], app.SUPPLY)

    def test_replay_and_double_faucet_rejected(self):
        old = self.fund()
        with self.assertRaises(ValueError):
            app.submit(*old)
        with self.assertRaises(ValueError):
            app.submit(*self.transaction(0, 'faucet', self.addresses[0], app.GRANT, 1))

    def test_overspend_and_invalid_amounts(self):
        self.fund()
        for value in (app.GRANT, -1, 0, 1.5, True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                app.submit(*self.transaction(0, 'transfer', self.addresses[1], value, 1))

    def test_modified_signature_and_wrong_chain(self):
        self.fund()
        tx, signature = self.transaction(0, 'transfer', self.addresses[1], 10, 1)
        tx[4] = 11
        with self.assertRaises(InvalidSignature):
            app.submit(tx, signature)
        tx[0] = 'other-chain'
        with self.assertRaises(ValueError):
            app.submit(tx, signature)

    def test_corrupted_block_detected(self):
        self.fund()
        with app.connect() as db:
            db.execute("UPDATE blocks SET hash='bad' WHERE height=1")
        with self.assertRaises(ValueError):
            app.initialize()


if __name__ == '__main__':
    unittest.main()
