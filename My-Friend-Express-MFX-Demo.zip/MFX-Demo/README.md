# My Friend Express — MFX Demo

Prototipe ledger berantai blok dengan satu node tepercaya, wallet web, tanda tangan Ed25519, transfer, pencatatan pembayaran, dan pengiriman reward manual.

**Bukan blockchain publik siap produksi. Coin demo tidak bernilai uang.** Belum ada P2P, konsensus antar-validator, finalitas terdistribusi, staking, listing bursa, atau integrasi pesanan toko. Admin node mengendalikan database; hash blok bukan perlindungan terhadap admin yang sengaja menulis ulang sejarah. Jangan menerima uang pelanggan menggunakan paket ini.

## Mulai dari HP tanpa VPS

1. Ekstrak ZIP di aplikasi Files/File Manager. Buat repository GitHub pribadi, misalnya `mfx-demo`.
2. Unggah isi folder `MFX-Demo` ke akar repository. Pastikan `app.py` dan `requirements.txt` langsung berada di akar, bukan di dalam folder tambahan. Mengunggah ZIP saja tidak membuat kode bisa dijalankan.
3. Melalui browser, buka repository lalu **Code → Codespaces → Create codespace on main**, jika Codespaces tersedia pada akunmu. Mode situs desktop dapat membantu pada layar HP. Periksa kuota dan biaya akun sebelum memakai layanan; paket ini tidak menyewa server atau mengaktifkan tagihan.
4. Di terminal Codespaces jalankan:

```bash
python -m pip install -r requirements.txt
python -m unittest -v
python app.py
```

5. Buka panel **Ports**, tambahkan port **8000** bila belum muncul, lalu pilih **Open in Browser**. Tetapkan visibilitas port **Private**. Gunakan URL HTTPS yang diberikan Codespaces, bukan `localhost:8000` di browser HP.
6. Tekan **Buat wallet**, lalu **Unduh cadangan wallet**. Simpan cadangan pribadi; isinya kunci rahasia tanpa enkripsi.
7. Tekan **Ambil 100 MFX percobaan**. Untuk mencoba transfer, buat wallet kedua pada profil/browser berbeda yang dapat mengakses codespace pribadi yang sama, lalu salin alamat penerimanya. Kedua browser harus mendukung Ed25519 Web Crypto.
8. Pilih Transfer, Pembayaran demo, atau Kirim reward demo. Masukkan alamat, jumlah, dan referensi seperti `ORDER-001`, lalu kirim.
9. Hentikan dengan Ctrl+C dan hentikan Codespace sesudah percobaan. Codespaces adalah lingkungan pengembangan, bukan hosting node 24 jam. Wallet tidak bisa bertransaksi jika proses node berhenti.

Jika folder tersembunyi tidak ikut terunggah dari HP, program tetap dapat dijalankan secara manual. Konfigurasi `.devcontainer/devcontainer.json` hanya menyiapkan Python dan port; `.github/workflows/test.yml` hanya menjalankan pengujian, bukan menyalakan jaringan.

## Menjalankan di komputer / terminal lain

Gunakan Python 3.12, masuk ke folder paket, lalu:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python app.py
```

Buka http://127.0.0.1:8000 pada komputer yang menjalankan proses. Di Windows, aktivasi lingkungan memakai `.venv\Scripts\activate`. Akses dari perangkat lain membutuhkan HTTPS dan pengaturan hosting tersendiri. Server HTTP bawaan paket ini hanya untuk pengembangan.

## Aturan demo

| Bagian | Nilai |
|---|---|
| Nama | My Friend Express |
| Simbol usulan | MFX |
| Chain ID | mfx-demo-1 |
| Pasokan simulasi | 1.000.000 MFX, awalnya di cadangan |
| Presisi | 2 angka desimal |
| Faucet | 100 MFX per alamat, sekali |
| Biaya transfer/pembayaran/reward | 0,01 MFX kembali ke cadangan |
| Blok | Satu transaksi diterima menghasilkan satu blok |
| Database | mfx.sqlite3 |

Faucet hanya membagikan cadangan yang sudah ada. Batas per alamat tidak mencegah satu orang membuat banyak alamat; jangan publikasikan faucet ini sebagai sistem distribusi ekonomi sungguhan.

Pembayaran adalah transfer dengan label dan referensi. Tidak ada verifikasi harga, stok, penerima merchant, penyelesaian pesanan, pengembalian dana, atau penukaran diskon. Reward adalah transfer dari saldo pengirim, bukan cashback otomatis dan bukan penerbitan coin baru. Label reward dapat dipakai siapa saja. Semua saldo/referensi dapat dilihat oleh pengguna yang bisa mengakses node: jangan isi nama, alamat rumah, nomor telepon, atau data pelanggan.

## Wallet, cadangan, dan database

- Private key dibuat dan transaksi ditandatangani di browser; API hanya menerima public key dan signature.
- Kunci browser disimpan di localStorage tanpa enkripsi. Perlindungan wallet produksi belum tersedia; jangan gunakan kunci ini di jaringan bernilai uang.
- Menghapus data browser atau mengganti alamat situs memerlukan pemulihan dari cadangan JSON.
- Jangan commit file cadangan wallet atau database ke GitHub. `.gitignore` sudah menyertakan pola keduanya.
- Cadangkan `mfx.sqlite3` secara terpisah setelah node dihentikan. Cadangan wallet tidak menyimpan ledger. Menghapus database menghapus semua saldo dan sejarah demo.
- Replay seluruh blok dilakukan saat startup, membaca saldo, dan menerima transaksi. Cocok untuk demo kecil, bukan lalu lintas produksi.
- Nonce mencegah pemakaian ulang transaksi pada ledger yang sama. Memulihkan database lama bisa membuka kembali nonce lama; jangan menganggap pemulihan database sebagai mekanisme konsensus.

## API

- `GET /` — wallet web.
- `GET /api/state` — saldo dalam unit terkecil, nonce berikutnya, cadangan, tinggi blok.
- `GET /api/blocks` — ringkasan 20 blok terakhir.
- `POST /api/tx` — objek `{ "tx": [...], "signature": "hex" }`.

Array transaksi: `[chain_id, jenis, public_key_hex, alamat_tujuan, jumlah_unit, nonce, referensi]`.
Signature Ed25519 menandatangani JSON UTF-8 tanpa spasi pemisah. Referensi dibatasi huruf/angka ASCII, spasi, titik, garis bawah, dan tanda minus; maksimal 60 karakter.

## Validasi paket

Pengujian backend mencakup pembayaran, reward, transfer ke diri sendiri, konservasi pasokan, pemuatan kembali database, penolakan nonce lama, faucet ganda, saldo tidak cukup, jumlah tidak valid, signature yang berubah, chain ID salah, dan deteksi hash blok rusak. Ini bukan audit keamanan. UI di Safari/iPhone dan deployment Codespaces belum diuji langsung dalam pembuatan paket.

## Langkah menuju jaringan publik

Gunakan kerangka blockchain yang matang dengan konsensus dan P2P; desain ulang genesis dan distribusi, validator independen, key management, explorer, wallet, perlindungan spam, pemantauan, backup, dan prosedur upgrade. Integrasi merchant harus memverifikasi jumlah, penerima, dan status transaksi di sisi server. Lakukan audit dan peninjauan kebutuhan hukum sebelum peluncuran dengan nilai uang. Paket demo ini bukan pengganti pekerjaan tersebut dan tidak menjanjikan listing atau harga coin.

## Referensi teknis

- https://cryptography.io/en/latest/hazmat/primitives/asymmetric/ed25519/
- https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto
- https://docs.github.com/en/codespaces/developing-in-a-codespace/forwarding-ports-in-your-codespace
